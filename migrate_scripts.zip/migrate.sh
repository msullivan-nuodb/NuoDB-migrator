#!/bin/bash

#
# Run ${ME} to display help with details on how to perform the migration.
#
ME=`basename $0`
#
# Modify the environment variables file to suit

. migrate.env

#
# Database Drivers Support and Settings:
#
#   Database    Driver                               URL Format
#
#   MySQL       com.mysql.jdbc.Driver              jdbc:mysql://host/dbname
#   Postgres    org.postgresql.Driver              jdbc:postgresql:dbname
#   Oracle      oracle.jdbc.OracleDriver           jdbc:oracle:thin:schema@host:port:SID
#   NuoDB       com.nuodb.jdbc.Driver              jdbc:com.nuodb://host:port/dbname?schema=schemaname
#   DB2         com.ibm.db2.jcc.DB2Driver          jdbc:db2://host:port/dbname
#   MSSQL       net.sourceforge.jtds.jdbc.Driver   jdbc:jtds:sqlserver://host:port/dbname
#
# The NuoDB Migrator does not have drivers for competing databases packaged in
#     the installation, with the exception of the NuoDB jdbc driver.
# In order to use the migrator, download the appropriate driver
#      and place it in the ${MIGRATOR_TOOL_DIR}/jar directory
#       (or download to some other location and add it to the CLASSPATH).
# Drivers may be obtained from the following sites:
#
#   Database    Driver URL
#
#   MySQL       http://search.maven.org/remotecontent?filepath=mysql/mysql-connector-java/5.1.28/mysql-connector-java-5.1.28.jar
#   Postgres    http://search.maven.org/remotecontent?filepath=org/postgresql/postgresql/9.3-1100-jdbc4/postgresql-9.3-1100-jdbc4.jar
#   Oracle      http://download.oracle.com/otn/utilities_drivers/jdbc/11204/ojdbc5.jar
#   NuodB       Installed with the product: /opt/nuodb/jar/nuodbjdbc.jar
#   DB2         http://www-01.ibm.com/support/docview.wss?uid=swg21363866
#   MSSQL       http://sourceforge.net/projects/jtds/files/jtds/
#

NUODB_MIGRATOR="${MIGRATOR_TOOL_DIR}/bin/nuodb-migrator"

os_type=`uname -s`
case $os_type in
    Darwin*)
        ECHO="echo -e"
    ;;
    Linux*)
        ECHO="echo -e"
    ;;
esac

case ${SOURCE_DATABASE_TYPE} in
    NUODB)
        SOURCE_DATABASE_URL="jdbc:com.nuodb://${SOURCE_DATABASE_HOST}:${SOURCE_DATABASE_PORT}/${SOURCE_DATABASE_NAME}"
        SOURCE_DATABASE_DRIVER="com.nuodb.jdbc.Driver"
        ;;
    ORACLE)
        SOURCE_DATABASE_URL="jdbc:oracle:thin:@${SOURCE_DATABASE_HOST}:${SOURCE_DATABASE_PORT}:${SOURCE_DATABASE_NAME}"
        SOURCE_DATABASE_DRIVER="oracle.jdbc.OracleDriver"
        ;;
    MYSQL)
        SOURCE_DATABASE_URL="jdbc:mysql://${SOURCE_DATABASE_HOST}:${SOURCE_DATABASE_PORT}/${SOURCE_DATABASE_NAME}?zeroDateTimeBehavior=round"
        SOURCE_DATABASE_DRIVER="com.mysql.jdbc.Driver"
        ;;
    MSSQLSERVER)
        SOURCE_DATABASE_URL="jdbc:jtds:sqlserver://${SOURCE_DATABASE_HOST}:${SOURCE_DATABASE_PORT}/${SOURCE_DATABASE_NAME}"
        SOURCE_DATABASE_DRIVER="net.sourceforge.jtds.jdbc.Driver"
        ;;
    POSTGRESQL)
        SOURCE_DATABASE_URL="jdbc:postgresql://${SOURCE_DATABASE_HOST}:${SOURCE_DATABASE_PORT}/${SOURCE_DATABASE_NAME}"
        SOURCE_DATABASE_DRIVER="org.postgresql.Driver"
        ;;
    IBMDB2)
        SOURCE_DATABASE_URL="jdbc:db2://${SOURCE_DATABASE_HOST}:${SOURCE_DATABASE_PORT}/${SOURCE_DATABASE_NAME}"
        SOURCE_DATABASE_DRIVER="com.ibm.db2.jcc.DB2Driver"
        ;;
    *)
        ECHO "Source Database Not Supported"
        EXIT 1
        ;;
esac

DUMP_DIRECTORY_DATA="${DUMP_DIRECTORY}/data"
DUMP_DIRECTORY_SCHEMA="${DUMP_DIRECTORY}/schema"

DUMP_COMMAND_PREFIX="${NUODB_MIGRATOR} dump --source.transaction.isolation=serializable --source.driver=${SOURCE_DATABASE_DRIVER} --source.url=${SOURCE_DATABASE_URL} --source.username=${SOURCE_DATABASE_USER} --source.password=${SOURCE_DATABASE_PASSWORD} --output.type=csv --output.path=${DUMP_DIRECTORY_DATA} --data=true --schema=true"

DUMP_COMMAND_NO_INDEX=" --meta.data.table=true --meta.data.sequence=true --meta.data.check=true --meta.data.column.trigger=true --meta.data.primary.key=false --meta.data.index=false --meta.data.foreign.key=false"

LOAD_COMMAND="${NUODB_MIGRATOR} load --target.url=jdbc:com.nuodb://${TARGET_DATABASE_HOST}:${TARGET_DATABASE_PORT}/${TARGET_DATABASE_NAME} --target.username=${TARGET_DATABASE_USER} --target.password=${TARGET_DATABASE_PASSWORD} --input.path=${DUMP_DIRECTORY_DATA} --data=true --schema=true"

SCHEMA_COMMAND_PREFIX="${NUODB_MIGRATOR} schema --source.transaction.isolation=serializable --source.driver=${SOURCE_DATABASE_DRIVER} --source.url=${SOURCE_DATABASE_URL} --source.username=${SOURCE_DATABASE_USER} --source.password=${SOURCE_DATABASE_PASSWORD}"

SCHEMA_COMMAND_INDEX=" --meta.data.primary.key=true --meta.data.index=true --meta.data.foreign.key=true --meta.data.table=false --meta.data.sequence=false --meta.data.check=false --meta.data.column.trigger=false"

SCHEMA_COMMAND_TARGET=" --target.url=jdbc:com.nuodb://${TARGET_DATABASE_HOST}:${TARGET_DATABASE_PORT}/${TARGET_DATABASE_NAME} --target.username=${TARGET_DATABASE_USER} --target.password=${TARGET_DATABASE_PASSWORD}"

if [ "${SOURCE_DATABASE_SCHEMA}" != "" ]
then
    case ${SOURCE_DATABASE_DRIVER} in
        com.mysql.jdbc.Driver)
            DUMP_COMMAND_PREFIX="${DUMP_COMMAND_PREFIX} --source.catalog=${SOURCE_DATABASE_SCHEMA}"
            SCHEMA_COMMAND_PREFIX="${SCHEMA_COMMAND_PREFIX} --source.catalog=${SOURCE_DATABASE_SCHEMA}"
            ;;
        *)
            DUMP_COMMAND_PREFIX="${DUMP_COMMAND_PREFIX} --source.schema=${SOURCE_DATABASE_SCHEMA}"
            SCHEMA_COMMAND_PREFIX="${SCHEMA_COMMAND_PREFIX} --source.schema=${SOURCE_DATABASE_SCHEMA}"
            ;;
    esac
fi

if [ "${SOURCE_DATABASE_TABLE}" != "" ]
then
    DUMP_COMMAND_PREFIX="${DUMP_COMMAND_PREFIX} --table=${SOURCE_DATABASE_TABLE}"
    SCHEMA_COMMAND_PREFIX="${SCHEMA_COMMAND_PREFIX} --table=${SOURCE_DATABASE_TABLE}"
fi


if [ "${TARGET_DATABASE_SCHEMA}" != "" ]
then
    LOAD_COMMAND="${LOAD_COMMAND} --target.schema=${TARGET_DATABASE_SCHEMA}"
    SCHEMA_COMMAND_TARGET="${SCHEMA_COMMAND_TARGET} --target.schema=${TARGET_DATABASE_SCHEMA}"
fi


function dump_data_only()
{
    rm -r ${DUMP_DIRECTORY_DATA}
    mkdir ${DUMP_DIRECTORY_DATA}

    ${ECHO} "[INFO]: Dumping database table definitions and data"
    ${ECHO} "${DUMP_COMMAND}"

    DUMP_COMMAND="${DUMP_COMMAND_PREFIX} ${DUMP_COMMAND_NO_INDEX}"
    ${DUMP_COMMAND}
}

function dump_data_indexes()
{
rm -r ${DUMP_DIRECTORY_DATA}
mkdir ${DUMP_DIRECTORY_DATA}

${ECHO} "[INFO]: Dumping database table definitions, data, and indexes"
${ECHO} "${DUMP_COMMAND_PREFIX}"

${DUMP_COMMAND_PREFIX}
}

function load_only()
{
    ${ECHO} "[INFO]: Loading database from dump files"
    ${ECHO} "${LOAD_COMMAND}"

    ${LOAD_COMMAND}
}


function dump_load_indexes()
{
    ${ECHO} "[INFO]: Dump and load database indexes"
    ${ECHO} "${SCHEMA_COMMAND}"

    SCHEMA_COMMAND="${SCHEMA_COMMAND_PREFIX} ${SCHEMA_COMMAND_INDEX} ${SCHEMA_COMMAND_TARGET}"
    ${SCHEMA_COMMAND}
}

function do_all()
{
dump_data_indexes
load_only
}

function do_all_in_steps()
{
if [ "${SOURCE_DATABASE_TABLE}" == "" ]
then
    dump_data_only
    load_only
    dump_load_indexes
else
    do_all
fi
}

function ddl_only()
{
rm -r ${DUMP_DIRECTORY_SCHEMA}
mkdir ${DUMP_DIRECTORY_SCHEMA}

SCHEMA_COMMAND="${SCHEMA_COMMAND_PREFIX} --output.path=${DUMP_DIRECTORY_SCHEMA}/schema_ddl.sql"

${ECHO} "[INFO]: Generate DDL only"
${ECHO} "${SCHEMA_COMMAND}"

${SCHEMA_COMMAND}
}

function help()
{
  cat <<'__EOF__'

  Requirements:

  - Procure a 32 GB Ram machine (if not this large, as large as you can get)
  - Start up a TE and SM both with --mem 16G; for smaller instances, give
    the TE and SM an equal amount of memory, and leave 1 GB for the OS.

  Tweaks:

  The default nuodb-migrator script is not optimally tuned for large databases
  out of the box; we recommend a couple tweaks to the migrator script located
  in /opt/nuodb/tools/migrator/bin. If you have a smaller database, then ignore
  this section. Otherwise, these settings should be enacted in the nuodb-migrator script:

   MAX_HEAP_SIZE="10G"  (the default value set is "256M")
   JAVA_OPTS="$JAVA_OPTS -XX:+UseG1GC"

  Debugging:

  Should problems arise, you can modify the Log4j settings in the file located
  in /opt/nuodb/tools/migrator/conf/log4j.properties by COMMENTING this line:

     #  --> log4j.logger.com.nuodb.migrator.jdbc.connection=none  <--

  Explanation:
  
  The migration occurs over a few steps to decrease the load time for the data.
  Namely, this process will defer the cost of index creation until all data is
  loaded.

  The migration may take 3.5 hours for large databases, and the tool will not
  provide any meaningful feedback while it is running, so just let it run to
  completion. You can look at the log file located at /tmp/nuodb-migrator.log (or %TEMP% directory on windows)

  This script is used to assist with the migration process. The overall process
  is as follows:

  - dump the table definitions and data, column constraints, and sequences
    - can also dump indexes
  - load the table definitions and data, column constraints, and sequences
    - can also load indexes IF they were dumped
  - dump and load the table indexes, primary keys, and foreign keys (no data)
             IF not loaded in the dump

  The operating sequence should be the following (after having already started
  up a NuoDB database whose target settings are specified above):

  $ migrate.sh do_all
  $ migrate.sh do_all_in_steps
  $ migrate.sh dump_data_only
  $ migrate.sh dump_data_indexes
  $ migrate.sh load_only
  $ migrate.sh dump_load_indexes
  $ migrate.sh ddl_only

  All functions of this script print out the elapsed time to run as the last
  output.

__EOF__
}

if [ $# -eq 0 ]; then
    ${ECHO} "\nSyntax:\n\t${ME} [<command> ...]\n\
\nCommands include:\
\n\t help                displays extended help and explanations\
\n\t do_all              generate tables and indexes, then load data (small databases)\
\n\t do_all_in_steps     generate tables, load data, then create indexes (large databases\
\n\t \
\n\t dump_data_only      dump the table data only\
\n\t dump_data_indexes   dump the table data and indexes\
\n\t load_only           load what was dumped, data only, or data and indexes\
\n\t \
\n\t dump_load_indexes   create indexes only. no data\
\n\t ddl_only            generate schema ddl only\
\n"
fi

while [ $# -gt 0 ]
do
    CMD=$1
    time {
      ${CMD}
      shift
    }
    ${ECHO} ""
done

exit

